#include <iostream>
using namespace std;
int main(){
    int value,result;
    cin >> value;
    cout << value * 220 << endl;
    system("pause");
    return 0;
}