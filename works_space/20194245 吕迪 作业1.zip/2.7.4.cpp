#include <iostream>
using namespace std;
int main(){
    int year,month;
    cout << "Enter your age: ";
    cin >> year;
    cout << year * 12 << endl;
    system("pause");
    return 0;
}