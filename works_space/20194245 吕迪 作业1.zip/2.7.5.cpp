#include <iostream>
using namespace std;
int main(){
    float C,F;
    float trans(float C);
    cin >> C;
    cout << C << trans(C);
    system("pause");
    return 0;
}
float trans(float C){
    return 1.8*C + 32.0;
}