#include <iostream>
using namespace std;
int main(){
    cout << "Lv Di" << endl;
    cout << "Address: Sichuan province" << endl;
    system("pause");
    return 0;
}